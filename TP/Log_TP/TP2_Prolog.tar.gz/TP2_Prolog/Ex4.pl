replique([], _, _).

replique([H|T], X, [List]):-
	replique(T, X, [H|List]).

